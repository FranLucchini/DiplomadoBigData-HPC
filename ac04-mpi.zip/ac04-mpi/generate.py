import os
from sys import argv
from random import randint

if len(argv) < 2:
    print('Call like: {} <size> <name>'.format(argv[0]))
    print('Or: {} <size>'.format(argv[0]))
    print('\t<size> Size of the problem')
    print('\t<name> Name for the txt to be put in ./test/ Defaults to <size>.txt')

file_path = './test/{}.txt'.format(argv[2] if len(argv) == 3 else argv[1])
size = int(argv[1])

with open(file_path, 'w') as file:
    file.write('{}\n'.format(size))
    size-=1
    while size > 0:
        for i in range(0, size):
            space = ' ' if i != size - 1 else ''
            file.write('{}{}'.format(randint(1, 9), space))
        file.write('\n')
        size-=1
