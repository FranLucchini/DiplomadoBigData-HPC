#include <stdio.h>
#include <stdlib.h>

struct Route {
  int *cities;
  int *visited;
  int size;
  int cost;
};

struct WSP {
  int size;
  int **roads;
  int *cities;
  int cost;
};

typedef struct Route Route;
typedef struct WSP WSP;

int route_should_visit(Route *route, int destination) {
  return route->visited[destination] == 0;
};

void route_advance(WSP *wsp, Route *route, int destination) {
  int origin = route->cities[route->size - 1];
  int cost = wsp->roads[origin][destination];
  route->cities[route->size] = destination;
  route->visited[destination] = 1;
  route->cost += cost;
  route->size += 1;
};

void route_return(WSP *wsp, Route *route, int destination) {
  int origin = route->cities[route->size - 2];
  int cost = wsp->roads[origin][destination];
  route->cities[route->size - 1] = 0;
  route->visited[destination] = 0;
  route->cost -= cost;
  route->size -= 1;
};

void route_dfs(WSP *wsp, Route *route) {
  // If route completed, check if best
  if (route->cities[wsp->size - 1] != 0) {
    if (wsp->cost == -1 || route->cost < wsp->cost) {
      wsp->cost = route->cost;
      for (int i = 0; i < wsp->size; i++) {
        wsp->cities[i] = route->cities[i];
      }
    }
    return;
  }

  // If worse than best, stop travelling
  if (wsp->cost != -1 && route->cost >= wsp->cost) {
    return;
  }

  // Keep travelling
  for (int destination = 1; destination < wsp->size; destination++) {
    if (route_should_visit(route, destination)) {
      route_advance(wsp, route, destination);
      route_dfs(wsp, route);
      route_return(wsp, route, destination);
    }
  }
}

Route *route_init(WSP *wsp) {
  Route *route = malloc(sizeof(Route));
  *route = (Route){.size = 1, .cost = 0};
  route->cities = calloc(wsp->size, sizeof(int *));
  route->cities[0] = 0;
  route->visited = calloc(wsp->size, sizeof(int *));
  route->visited[0] = 1;
  for (int i = 1; i < wsp->size; i++) {
    route->cities[i] = 0;
    route->visited[i] = 0;
  }
  return route;
};

WSP *wsp_init(char *input) {
  FILE *file = fopen(input, "r");
  int size;
  fscanf(file, "%i", &size);
  WSP *wsp = malloc(sizeof(WSP));
  *wsp = (WSP){.size = size, .cost = -1};

  wsp->cities = calloc(size, sizeof(int));
  wsp->roads = calloc(size, sizeof(int *));
  for (int origin = 0; origin < size; origin++) {
    wsp->roads[origin] = calloc(size, sizeof(int));
  }
  for (int origin = 0; origin < size; origin++) {
    for (int destination = origin + 1; destination < size; destination++) {
      int cost;
      fscanf(file, "%i", &cost);
      wsp->roads[origin][destination] = cost;
      wsp->roads[destination][origin] = cost;
    }
  }
  fclose(file);
  return wsp;
};

void route_print(Route *route) {
  printf("Route cost %i\n\t", route->cost);
  for (int i = 0; i < route->size; i++) {
    printf("%i ", route->cities[i]);
  }
  printf("\n");
};

void wsp_print_route(WSP *wsp) {
  printf("Route cost %i: ", wsp->cost);
  for (int i = 0; i < wsp->size; i++) {
    printf("%i ", wsp->cities[i]);
  }
  printf("\n");
};

void route_free(WSP *wsp, Route *route) {
  free(route->cities);
  free(route->visited);
  free(route);
};

void wsp_free(WSP *wsp) {
  for (int origin = 0; origin < wsp->size; origin++) {
    free(wsp->roads[origin]);
  }
  free(wsp->cities);
  free(wsp->roads);
  free(wsp);
};
