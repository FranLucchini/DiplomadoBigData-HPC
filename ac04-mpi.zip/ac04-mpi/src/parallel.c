#include "shared.c"
#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
  /* The program receives 1 param */
  if (argc != 2) {
    printf("Modo de uso: %s <input.txt>\n", argv[0]);
    printf("\t<input.txt> es el problema a resolver\n");
    return 1;
  }
  MPI_Init(&argc, &argv);
  WSP *wsp = wsp_init(argv[1]);
  int nodes, node, len;
  char host[MPI_MAX_PROCESSOR_NAME];
  MPI_Comm_size(MPI_COMM_WORLD, &nodes);
  MPI_Comm_rank(MPI_COMM_WORLD, &node);
  MPI_Get_processor_name(host, &len);

  // Mapeamos destinos a los nodos
  int dest_nodes = (wsp->size - 1) / nodes + 1;
  int dest_for_node[nodes][dest_nodes + 1];
  int i = 0, j = 0;
  for (int dest = 1; dest < wsp->size; dest++) {
    dest_for_node[i][j] = dest;
    if (i == nodes - 1) {
      i = 0;
      j++;
    } else {
      i++;
    }
  }

  // Resolvemos los destinos correspondientes a nuestro nodo
  for (int i = 0; i < dest_nodes; i++) {
    int dest = dest_for_node[node][i];
    if (dest >= wsp->size || dest <= 0) {
      // printf("dest %i node %i host %s out\n", dest, node, host);
      break;
    }
    // printf("dest %i node %i host %s\n", dest, node, host);
    Route *route = route_init(wsp);
    route_advance(wsp, route, dest);
    route_dfs(wsp, route);
    route_free(wsp, route);
  }

  printf("node %i\n", node);
  wsp_print_route(wsp);
  wsp_free(wsp);
  MPI_Finalize();
  return 0;
}
