# Actividad MPI

### Generar archivo de prueba
```bash
python3 generate.py <tamaño>
python3 generate.py <tamaño> <nombre>
# <nombre> es ./test/<tamaño>.txt si no se especifica
```

### Compilar código
```bash
cd mpi/
make
```

### Correr programa
```bash
# Versión secuencial
time ./secuential.o ./test/12.txt

# Múltiples procesos locales
# -N <número de procesos>
time mpirun -N 4 ./parallel.o ./test/12.txt

# Múltiples procesos en múltiples nodos
# -N <número de procesos>
# -hostfile <nodos>
time mpirun -hostfile ./hosts.txt -N 4 ./parallel.o ./test/12.txt
```

**Importante**: Número de nodos no puede ser menor al tamaño del problema
